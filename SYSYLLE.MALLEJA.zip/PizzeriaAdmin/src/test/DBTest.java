package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class DBTest {
	
	
	

public static void main (String args [])  {
	
	//tulostetaan sivun alkuun tarvittavat html-tagit
			System.out.println("<!DOCTYPE html>");
			System.out.println("<html>");
			System.out.println("<body>");
			
			
			//TIETOKANTAHAKU
			
			String username = "a1500948";
			String password = "wuMYTy73o";
			String url = "jdbc:mariadb://localhost/a1500948";

			Connection yhteys = null;
			
			try {
				//YHTEYDEN AVAUS JA HAKU
				//ajurin lataus
				Class.forName("org.mariadb.jdbc.Driver").newInstance();
				//avataan yhteys
				yhteys = DriverManager.getConnection(url, username, password);
				
				//suoritetaan haku
				String sql = "select * from pizza";
				Statement haku = yhteys.createStatement();
				ResultSet pizza = haku.executeQuery(sql);
				
				//k�yd��n hakutulokset l�pi
				while(pizza.next()) {
					int id = pizza.getInt("id");
					String nimi = pizza.getString("nimi");
					double hinta = pizza.getDouble("hinta");
					
					//tulostetaan yksitt�inen hakutulos responseen
					System.out.println(id + ". " + nimi +" " +hinta +"<br/>");
				}
				
			} catch(Exception e) {
				//JOTAIN VIRHETT� TAPAHTUI
				e.printStackTrace();
				System.out.println("<p style=\"color:red\">Tietokantahaku aiheutti virheen</p>");
			} finally {
				//LOPULTA AINA SULJETAAN YHTEYS
				try {
					if (yhteys != null && !yhteys.isClosed())
						yhteys.close();
				} catch(Exception e) {
					System.out.println("Tietokantayhteys ei jostain syyst� suostu menem��n kiinni.");
				}
			}
			
			
			//suljetaan viel� webbisivun html-tagit
			System.out.println("</body></html>");
	
	
	

}}
