package fi.omapizzeria.admin.controller;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.PizzaDAO;
import fi.omapizzeria.admin.bean.Pizza;

/**
 * Kotiteht�v� 1
 * 
 * @author B�rlund Joni
 *
 */

@WebServlet("/controller")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public ControllerServlet() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		java.io.PrintWriter wout = response.getWriter();

		// tietokannasta pizzat
		PizzaDAO pDao = new PizzaDAO();

		pDao.avaaYhteys();

		List<Pizza> lista = null;
		lista = pDao.haePizzat();
		for (int i = 0; i < lista.size(); i++) {
			wout.print(lista.get(i));
		}

		pDao.suljeYhteys();
		/*
		 * // requestiin talteen request.setAttribute("pizzat", lista);
		 */

		Date aloitusaika = new Date();
		HttpSession sessio = request.getSession();
		sessio.setAttribute("kello", aloitusaika);

		// tallennetaan luotu olio requestin atribuutiksi
		request.setAttribute("pizzat", lista);

		// ohjataan pyynt� jsp-sivulle, joka hoitaa tulostuksen muotoilun
		request.getRequestDispatcher("list.jsp").forward(request, response);
		wout.close();
	}

	// }

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		response.getWriter();

		// Luetaan HTML-Lomakkeelle t�ytetyt tiedot

		if (request.getParameter("nimi") != null
				&& request.getParameter("hinta") != null) {
			String id = request.getParameter("id");
			int id1 = Integer.parseInt(id);
			String Nimi = request.getParameter("nimi");
			String Hinta = request.getParameter("hinta");
			String t�ytteet = request.getParameter("t�ytteet");
			double Hinta1 = Double.parseDouble(Hinta);
			Pizza pizza = new Pizza(id1, Nimi, Hinta1, t�ytteet);
			DecimalFormat formaatteri = new DecimalFormat("0.00");

			System.out.println("<p>");
			System.out.println("<b>" + pizza.getNimi() + "</b>");
			System.out.println("<b> T�ytteet: " + pizza.getT�ytteet()  + "</b>");
			System.out.println("<br/>");
			System.out.println("Hinta: " + formaatteri.format(pizza.getHinta())
					+ " EUR");

			System.out.println("</p>");

			Pizza p = new Pizza(id1, Nimi, Hinta1, t�ytteet);
			PizzaDAO pDao = new PizzaDAO();

			try {
				pDao.avaaYhteys();
				pDao.lisaaPizza(p);
				pDao.suljeYhteys();
			} catch (Exception e) {
				throw new ServletException(e);

			}
			response.sendRedirect("controller");
		}

		else {
			PizzaDAO pDao = new PizzaDAO();
			int poistettavaid = Integer.parseInt(request.getParameter("id"));
			/*int p�ivit�id = Integer.parseInt(request.getParameter("id"));*/
			System.out.println("ID: " + poistettavaid);

			try {
				pDao.avaaYhteys();
				pDao.poistaPizza(poistettavaid);
				/*pDao.aloitaIDedellisesta(p�ivit�id);
*/				pDao.suljeYhteys();
			} catch (Exception e) {
				throw new ServletException(e);

			}

			response.sendRedirect("controller");

			/*
			 * wout.println("<p>"); wout.println("<b>" + pizza.getNimi() +
			 * "</b>"); wout.println("<br/>"); wout.println("Hinta: " +
			 * formaatteri.format(pizza.getHinta()) + " EUR");
			 * wout.println("</p>");
			 */

		}
	}
}
