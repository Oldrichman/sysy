package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import fi.omapizzeria.admin.bean.Pizza;

public class PizzaDAO {

	private Connection yhteys = null;

	public void avaaYhteys() {
		// TIETOKANTAHAKU

		String username = "a1500948";
		String password = "wuMYTy73o";
		String url = "jdbc:mariadb://localhost/a1500948";

		// YHTEYDEN AVAUS JA HAKU
		// ajurin lataus
		try {
			Class.forName("org.mariadb.jdbc.Driver").newInstance();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// avataan yhteys
		try {
			yhteys = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void suljeYhteys() {
		try {
			yhteys.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<Pizza> haePizzat() {

		ArrayList<Pizza> pizzat = new ArrayList<Pizza>();

		try {

			// suoritetaan haku
			String sql = "select * from pizza";
			Statement haku = yhteys.createStatement();
			ResultSet resultset = haku.executeQuery(sql);

			// k�yd��n hakutulokset l�pi
			while (resultset.next()) {
				Pizza pizza = new Pizza();
				pizza.setId(resultset.getInt("id"));

				pizza.setNimi(resultset.getString("nimi"));

				pizza.setT�ytteet(resultset.getString("t�ytteet"));
				

				pizza.setHinta(resultset.getDouble("hinta"));

				pizzat.add(pizza);
			}

		} catch (Exception e) {
			// JOTAIN VIRHETT� TAPAHTUI
			System.out.println("Tietokantahaku aiheutti virheen");
		} finally {

		}

		System.out.println("HAETTIIN TIETOKANNASTA PIZZAT: "
				+ pizzat.toString());

		return pizzat;
	}

	public void lisaaPizza(Pizza p) {

		try {

			// suoritetaan haku

			// alustetaan sql-lause

			String sql = "insert into pizza(id, nimi, hinta, t�ytteet) values(?,?,?,?)";

			PreparedStatement resultset = yhteys.prepareStatement(sql);

			// t�ytet��n puuttuvat tiedot
			resultset.setInt(1, p.getId());
			resultset.setString(2, p.getNimi());
			resultset.setDouble(3, p.getHinta());
			resultset.setString(4, p.getT�ytteet());
		

			// suoritetaan lause
			resultset.executeUpdate();
			System.out.println("LIS�TTIIN PIZZA TIETOKANTAAN: " + p);
		} catch (Exception e) {
			// JOTAIN VIRHETT� TAPAHTUI
			System.out.println("Pizza lis��misyritys aiheutti virheen");
			System.out.println(e);
		} finally {
		}

	}

	public void poistaPizza(int id) {
		try {

			String sql = "DELETE FROM pizza WHERE id = ?";
			PreparedStatement st = yhteys.prepareStatement(sql);

			st.setInt(1, id);
			st.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/*public void aloitaIDedellisesta(int id) {

		try {
			String sql = " ALTER TABLE pizza  AUTO_INCREMENT = 1";

			PreparedStatement st = yhteys.prepareStatement(sql);

			st.executeUpdate();

			ResultSet tableKeys = st.getGeneratedKeys();
			tableKeys.next();
			id = tableKeys.getInt(1);

		} catch (Exception e) {
			System.out.println(e);
		}
	}*/

}
